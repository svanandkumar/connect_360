package com.ibm.gbs.wcm.vo;

import java.math.BigDecimal;

public class ReferralPersonLAVo {

	private BigDecimal personID ;
	private String clientID ;
	private String customerName ;
	private String DOB ;
	private String gender ;
	private String relationship ;
	private String address ;
	private String memberID ;
	private String fName ;
	private String lName ;
	public BigDecimal getPersonID() {
		return personID;
	}
	public void setPersonID(BigDecimal personID) {
		this.personID = personID;
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public String getFName() {
		return fName;
	}
	public void setFName(String fName) {
		this.fName = fName;
	}
	public String getLName() {
		return lName;
	}
	public void setLName(String lName) {
		this.lName = lName;
	}
}
