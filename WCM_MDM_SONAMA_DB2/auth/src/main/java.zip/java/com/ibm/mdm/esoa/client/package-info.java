@javax.xml.bind.annotation.XmlSchema(namespace = "http://client.esoa.mdm.ibm.com/")
package com.ibm.mdm.esoa.client;
