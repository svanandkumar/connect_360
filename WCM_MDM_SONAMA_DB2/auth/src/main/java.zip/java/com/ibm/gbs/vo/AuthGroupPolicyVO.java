/* Licensed Materials - 
 Property of IBM 6949 - 67L 
 Copyright IBM Corp. 2017, 2018 All Rights Reserved */
package  com.ibm.gbs.vo;

public class AuthGroupPolicyVO {
	
	private long authGroupId ;
	private long policySetID ;
	
	public long getAuthGroupId() {
		return authGroupId;
	}
	public void setAuthGroupId(long authGroupId) {
		this.authGroupId = authGroupId;
	}
	public long getPolicySetID() {
		return policySetID;
	}
	public void setPolicySetID(long policySetID) {
		this.policySetID = policySetID;
	}
	
	

}
