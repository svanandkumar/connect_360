/* Licensed Materials - 
 Property of IBM 6949 - 67L 
 Copyright IBM Corp. 2017, 2018 All Rights Reserved */
package  com.ibm.gbs.util;

public class Constant {

	//public static final String SCHEMANAME = "system" ; // consentmgt
	//public static final String SCHEMANAME = "consmgmt_UI" ;
	
	/* ------------------------DB2 ------------------------------------- */
	public static final String SCHEMANAME = "CONSENTMGT" ;
	public static final String SCHEMANAME_ODS   = "CONNECT360_INT" ;
	public static final String SCHEMANAME_ConsetMGMT   = "CONSENTMGT" ;
	/* ------------------------Oracle----------------------------------------- */
	
		//public static final String SCHEMANAME = "consmgmt_UI" ;		
		//public static final String SCHEMANAME_ODS   = "consmgmt_UI" ;
	//public static final String SCHEMANAME_ConsetMGMT   = "consmgmt_UI" ;
}